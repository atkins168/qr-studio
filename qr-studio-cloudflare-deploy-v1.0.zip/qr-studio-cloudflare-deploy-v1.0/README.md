# QR Studio 一键发布到 Cloudflare（v1.0）

双击 `deploy-qr-studio.bat`（或 `node deploy-qr-studio.mjs`），按提示走完即可。
脚本幂等，可反复运行；每次运行都会重新部署 Worker + Pages 并刷新代理地址。

## 目录结构

```
.
├── deploy-qr-studio.mjs   一键部署脚本（Node 18+）
├── deploy-qr-studio.bat   Windows 双击入口（纯 ASCII）
├── VERSION                版本号
├── README.md              本文件
├── site/
│   └── index.html         网站本体（三语 i18n 版，发布到 Pages）
└── worker/
    └── worker.js          CORS 图片代理（发布为 Worker，供 ChromaCode 取 favicon）
```

## 前置条件

1. 安装 Node.js 18+（https://nodejs.org，选 LTS）
2. 登录 wrangler：命令行跑一次 `npx wrangler login`，按提示在浏览器里授权
3. 国内网络：如果连不上 Cloudflare，先执行
   `set HTTPS_PROXY=http://127.0.0.1:10808`

## 脚本会做的事

1. 检查 Node.js 版本和 wrangler 登录状态
2. 部署 `worker/worker.js` 为代理 Worker（默认名 `qr-studio-proxy`）
3. 把 Worker 的 `https://…workers.dev` 地址写进 `site/index.html` 的 `MY_PROXY`
   （ChromaCode 取 favicon 时优先走自己的代理，失败自动降级到公共代理）
4. 创建（或复用）Pages 项目（默认名 `qr-studio`）并发布 `site/`
5. 输出网站地址：`https://qr-studio.pages.dev`

## 常用参数

```
node deploy-qr-studio.mjs --yes
node deploy-qr-studio.mjs --proxy-url https://abc123.workers.dev
node deploy-qr-studio.mjs --worker-name my-proxy --pages-name my-qr
```

- `--yes`：全自动，不停下来确认
- `--proxy-url`：已有代理 Worker 时跳过部署，只填地址并发布 Pages
- `--worker-name` / `--pages-name`：自定义 Worker 名 / Pages 项目名

## 常见问题

- **wrangler 未登录**：先跑 `npx wrangler login` 再重跑脚本
- **Worker 名被占用**：部署报错时换个名字，如 `--worker-name qr-proxy-02`
- **发布后 MY_PROXY 没生效**：脚本每次运行都会重写该字段，直接重跑一次即可
