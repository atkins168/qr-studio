#!/usr/bin/env node
/**
 * QR Studio 一键发布到 Cloudflare（Windows / macOS / Linux 通用）
 *
 * 用法（在这个目录下）:
 *   node deploy-qr-studio.mjs                        # 交互式：关键步骤会停下来确认
 *   node deploy-qr-studio.mjs --yes                   # 全自动：全部按默认走
 *   node deploy-qr-studio.mjs --proxy-url https://xxx.workers.dev   # 已有代理 Worker，只填地址并发布 Pages
 *   node deploy-qr-studio.mjs --worker-name my-proxy --pages-name my-qr
 *
 * 前置条件:
 *   1. Node.js 18+（node -v 确认）
 *   2. 已登录 wrangler：先跑一次 `npx wrangler login`（浏览器授权）
 *      或设置环境变量 CLOUDFLARE_API_TOKEN
 *   3. 国内网络连不上 Cloudflare 时：set HTTPS_PROXY=http://127.0.0.1:10808
 *
 * 脚本做的事（全部幂等，可反复跑）:
 *   1. 检查 node / wrangler 登录状态
 *   2. 部署 worker/worker.js 为代理 Worker（默认名 qr-studio-proxy）
 *   3. 把 Worker 地址回填进 site/index.html 的 MY_PROXY（ChromaCode 取 favicon 用）
 *   4. 创建（或复用）Pages 项目并发布 site/（默认名 qr-studio）
 */

import { execFileSync, spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();
const IS_WIN = process.platform === 'win32';
const ARGS = process.argv.slice(2);
const AUTO_YES = ARGS.includes('--yes') || ARGS.includes('-y');

function argVal(name, def) {
  const i = ARGS.findIndex((a) => a === name);
  if (i >= 0 && ARGS[i + 1] && !ARGS[i + 1].startsWith('--')) return ARGS[i + 1];
  const eq = ARGS.find((a) => a.startsWith(name + '='));
  if (eq) return eq.slice(name.length + 1);
  return def;
}
const WORKER_NAME = argVal('--worker-name', 'qr-studio-proxy');
const PAGES_NAME = argVal('--pages-name', 'qr-studio');
const PROXY_URL_ARG = argVal('--proxy-url', '');

// ---------- 小工具 ----------

function log(msg = '') { console.log(msg); }
function step(n, msg) { console.log(`\n[步骤 ${n}] ${msg}`); }
function ok(msg) { console.log(`  ✓ ${msg}`); }
function warn(msg) { console.log(`  ! ${msg}`); }
function fail(msg) {
  console.error(`\n  ✗ 失败: ${msg}`);
  process.exit(1);
}

/** 跑一条命令，返回 stdout；失败抛错 */
function run(cmd, args, opts = {}) {
  const { file, fargs } = IS_WIN ? winCmd(cmd, args) : { file: cmd, fargs: args };
  try {
    return execFileSync(file, fargs, {
      encoding: 'utf8', stdio: 'pipe',
      cwd: opts.cwd || ROOT,
      env: { ...process.env, ...(opts.env || {}) },
      maxBuffer: 64 * 1024 * 1024,
    });
  } catch (e) {
    const err = new Error(`命令失败: ${cmd} ${args.join(' ')}\n${(e.stdout || '')}${(e.stderr || e.message)}`);
    err.stdout = e.stdout; err.stderr = e.stderr;
    throw err;
  }
}

/** 跑一条命令，实时输出（用于 wrangler deploy 这类长输出） */
function runLive(cmd, args, opts = {}) {
  const { file, fargs } = IS_WIN ? winCmd(cmd, args) : { file: cmd, fargs: args };
  const r = spawnSync(file, fargs, {
    stdio: 'inherit', cwd: opts.cwd || ROOT, env: { ...process.env, ...(opts.env || {}) },
  });
  if (r.status !== 0) fail(`命令失败: ${cmd} ${args.join(' ')}（退出码 ${r.status}）`);
}

/** Windows 下走 cmd.exe /d /s /c，传裸命令名（npx），由 cmd 按 PATHEXT 解析 */
function winCmd(cmd, args) {
  const q = (a) => {
    const s = String(a);
    return /[\s"]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return { file: 'cmd.exe', fargs: ['/d', '/s', '/c', `${cmd} ${args.map(q).join(' ')}`] };
}

function extractWranglerError(msg) {
  const lines = String(msg).split('\n');
  const errs = lines.filter((l) => /\[ERROR\]/.test(l));
  if (errs.length) return errs.join('\n');
  return lines.filter((l) => l.trim()).slice(0, 6).join('\n');
}

async function confirm(msg) {
  if (AUTO_YES) return true;
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const ans = await new Promise((r) => rl.question(`${msg} [Y/n] `, r));
  rl.close();
  return !/^n/i.test(ans.trim());
}

// ---------- 主流程 ----------

async function main() {
  log('=== QR Studio 一键发布到 Cloudflare ===');
  log(`  代理 Worker 名: ${WORKER_NAME}`);
  log(`  Pages 项目名:   ${PAGES_NAME}`);

  // 步骤 1: node 版本
  step(1, '检查 Node.js');
  const nv = process.version;
  const major = parseInt(nv.slice(1).split('.')[0], 10);
  if (major < 18) fail(`Node.js 版本过低: ${nv}，需要 18+`);
  ok(`Node.js ${nv}`);

  // 步骤 2: wrangler 登录
  step(2, '检查 wrangler 登录状态');
  try {
    const who = run('npx', ['wrangler', 'whoami']);
    const m = who.match(/You are logged in as ([^\n]+)/);
    ok(`已登录: ${m ? m[1].trim() : '（见上）'}`);
  } catch (e) {
    fail('wrangler 未登录。请先跑一次 `npx wrangler login`（浏览器授权），\n再重新运行本脚本。国内网络需要先 set HTTPS_PROXY=http://127.0.0.1:10808');
  }

  // 步骤 3: 部署代理 Worker（或用 --proxy-url 跳过）
  let proxyUrl = PROXY_URL_ARG.replace(/\/+$/, '');
  if (proxyUrl) {
    step(3, '使用指定的代理 Worker 地址（跳过部署）');
    ok(proxyUrl);
  } else {
    step(3, `部署代理 Worker: ${WORKER_NAME}`);
    const workerDir = join(ROOT, 'worker');
    if (!existsSync(join(workerDir, 'worker.js'))) fail('找不到 worker/worker.js');
    // 生成 wrangler.toml（幂等）
    const today = new Date().toISOString().slice(0, 10);
    writeFileSync(join(workerDir, 'wrangler.toml'),
      `name = "${WORKER_NAME}"\nmain = "worker.js"\ncompatibility_date = "${today}"\n`);
    ok('已生成 worker/wrangler.toml');
    let out = '';
    try {
      // 用 run 捕获输出以解析 workers.dev 地址
      out = run('npx', ['wrangler', 'deploy'], { cwd: workerDir });
      log(out.split('\n').filter((l) => /workers\.dev|Uploaded|Published/i.test(l)).join('\n'));
    } catch (e) {
      fail(`Worker 部署失败:\n${extractWranglerError(e.message)}\n（如名字被占用，换个 --worker-name 再试）`);
    }
    const m = out.match(/https:\/\/[a-z0-9-]+\.[a-z0-9-]+\.workers\.dev/i);
    if (!m) fail('部署看似成功，但没从输出里找到 workers.dev 地址，请手动查看后用 --proxy-url 指定');
    proxyUrl = m[0];
    ok(`代理 Worker 地址: ${proxyUrl}`);
  }

  // 步骤 4: 回填 MY_PROXY
  step(4, '把代理地址写入 site/index.html（MY_PROXY）');
  const indexPath = join(ROOT, 'site', 'index.html');
  if (!existsSync(indexPath)) fail('找不到 site/index.html');
  let html = readFileSync(indexPath, 'utf8');
  if (!/MY_PROXY='[^']*'/.test(html)) fail('site/index.html 里找不到 MY_PROXY 标记');
  html = html.replace(/MY_PROXY='[^']*'/, `MY_PROXY='${proxyUrl}'`);
  writeFileSync(indexPath, html);
  ok(`MY_PROXY='${proxyUrl}'`);

  // 步骤 5: Pages 发布
  step(5, `发布到 Cloudflare Pages: ${PAGES_NAME}`);
  if (!(await confirm('开始发布 Pages？'))) fail('已取消');
  try {
    run('npx', ['wrangler', 'pages', 'project', 'create', PAGES_NAME]);
    ok(`Pages 项目已创建: ${PAGES_NAME}`);
  } catch (e) {
    // 已存在会报错，忽略继续
    warn('项目可能已存在，继续发布…');
  }
  runLive('npx', ['wrangler', 'pages', 'deploy', 'site', '--project-name', PAGES_NAME]);

  log('\n=== 发布完成 ===');
  log(`  网站地址: https://${PAGES_NAME}.pages.dev`);
  log(`  代理地址: ${proxyUrl}`);
  log('  说明: ChromaCode 取 favicon 时优先走你自己的代理，失败时自动降级到公共代理。');
}

main().catch((e) => fail(e.message || String(e)));
